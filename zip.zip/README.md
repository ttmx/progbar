# Luke's dmenu

This is just my build of dmenu. Nothing special, don't bother starring ;-)

Only changes are minor config ones: bigger font and different colors.

The only reason this is even on Github is so LARBS can access the build, although this repo serves the additional purpose of using Github's metrics to approximate the number of people who install LARBS every day.

## Installation

After making any config changes that you want, but `make`, `sudo make install` it.
